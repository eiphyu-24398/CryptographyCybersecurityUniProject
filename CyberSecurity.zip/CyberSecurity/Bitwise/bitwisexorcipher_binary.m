function bitwisexorbinary(msg)

msg = input('Enter a secret message: ', 's');
msg = lower(msg);
key = input('Enter a key: ', 's');

% length of text and key
textLength = length(msg);
keyLength = length(key);

% Initialize encrypted text and decrypted text arrays
encryptedText = zeros(1, textLength, 'uint32');
decryptedText = char(zeros(1, textLength));

% Encrypting the text using XOR operation
for i = 1:textLength
    encryptedText(i) = bitxor(uint32(msg(i)), uint32(key(mod(i-1, keyLength) + 1)));
end

% Displaying the encrypted text (numeric ASCII codes)
fprintf('Encrypted Text (in ASCII codes): ');
disp(encryptedText);

% Decrypting the text using XOR operation
for i = 1:textLength
    decryptedText(i) = char(bitxor(encryptedText(i), uint32(key(mod(i-1, keyLength) + 1))));
end 

% Displaying the decrypted text
fprintf('Decrypted Text: %s\n', decryptedText);
end
