function bitwisexor()
% XOR encryption with a key

plaintext = input('Enter a message: ', 's');
key = 'EDR141'; 

% XOR encryption
encrypted_binary = xor_encrypt(plaintext, key);

% Encrypted binary with the same key again
decrypted_binary = xor_encrypt(encrypted_binary, key);

decrypted_str = char(bin2dec(reshape(char(decrypted_binary + '0'), 8, []).'));

% Decrypted string
disp('Decrypted String:');
disp(decrypted_str);

% Decrypted string matches the original plaintext
disp('Is Decryption Correct?');
disp(strcmp(plaintext, decrypted_str));

% XOR encryption at bitwise level
function encrypted_binary = xor_encrypt(plaintext, key)
    binary = reshape(dec2bin(plaintext, 8).' - '0', 1, []);

    key = repmat(key, 1, ceil(length(binary) / length(key)));

    % XOR operation
    encrypted_binary = xor(binary, key(1:length(binary)));

    disp('Encrypted Binary:');
    disp(encrypted_binary);

    encrypted_str = char(bin2dec(reshape(char(encrypted_binary + '0'), 8, []).'));

    disp('Encrypted String:');
    disp(encrypted_str);
end
end
