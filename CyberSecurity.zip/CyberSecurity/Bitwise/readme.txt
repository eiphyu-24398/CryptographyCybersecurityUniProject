{\rtf1\ansi\ansicpg1252\cocoartf2709
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\froman\fcharset0 TimesNewRomanPSMT;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;\red224\green233\blue240;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c0;\cssrgb\c90313\c93062\c95303;}
\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\sa320\partightenfactor0

\f0\fs32 \cf2 \expnd0\expndtw0\kerning0
This is a simple command-line tool for encrypting and decrypting messages using the XOR cipher algorithm.\
The XOR cipher is a basic symmetric encryption technique that operates on binary data. It applies the XOR (exclusive OR) operation between each character of the message and the corresponding element of a key. The same key is used for both encryption and decryption.}