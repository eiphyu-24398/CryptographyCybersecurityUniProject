% Visualization of Growth Rates
% Generating input values (n)
n = 1:20;

% Plotting constant, linear, logarithmic, quadratic, and exponential growth
figure;
plot(n, ones(size(n)), '-o', 'DisplayName', 'O(1) - Constant');
hold on;
plot(n, n, '-o', 'DisplayName', 'O(n) - Linear');
plot(n, log2(n), '-o', 'DisplayName', 'O(log n) - Logarithmic');
plot(n, n.^2, '-o', 'DisplayName', 'O(n^2) - Quadratic');
plot(n, 2.^n, '-o', 'DisplayName', 'O(2^n) - Exponential');

% Setting axis labels and title
xlabel('Input Size (n)');
ylabel('Operations');
title('Complexity Growth Rates');
legend('Location', 'northwest');


% Timing Mechanisms

% Using tic and toc
tic;
constantTime();
elapsedTime = toc;
disp(['Elapsed Time: ', num2str(elapsedTime), ' seconds']);

% Using timeit function
elapsedTime = timeit(@() linearTime(100));
disp(['Elapsed Time: ', num2str(elapsedTime), ' seconds']);

% Using profile
profile on;
quadraticTime(50);
profile off;

% Checking if profview is supported
if ~isdeployed
    try
        profview;
    catch
        disp('profview is not supported on this platform.');
    end
else
    disp('profview is not supported on this platform.');
end


% Importance of Complexity in Cryptography
disp('The measure of complexity is important in cryptography because:');
disp('- Cryptographic algorithms need to be efficient to handle large data sets.');
disp('- Time complexity affects the practicality of the algorithm in real-world applications.');
disp('- A balance between security and performance is crucial for cryptographic algorithms.');


% Stats Option in the Menu
disp('You can implement a stats option in the menu to provide information on timings, memory usage, etc.');


% Time Complexity Demonstrations

% Constant time complexity - O(1)
function constantTime()
    disp('Constant Time Complexity - O(1)');
end

% Linear time complexity - O(n)
function linearTime(n)
    disp(['Linear Time Complexity - O(n), n = ', num2str(n)]);
    for i = 1:n
        
    end
end

% Logarithmic time complexity - O(log n)
function logarithmicTime(n)
    disp(['Logarithmic Time Complexity - O(log n), n = ', num2str(n)]);
    for i = 1:log2(n)
        
    end
end

% Quadratic time complexity - O(n^2)
function quadraticTime(n)
    disp(['Quadratic Time Complexity - O(n^2), n = ', num2str(n)]);
    for i = 1:n
        for j = 1:n
            
        end
    end
end

% Exponential time complexity - O(2^n)
function exponentialTime(n)
    disp(['Exponential Time Complexity - O(2^n), n = ', num2str(n)]);
    for i = 1:2^n
       
    end
end
