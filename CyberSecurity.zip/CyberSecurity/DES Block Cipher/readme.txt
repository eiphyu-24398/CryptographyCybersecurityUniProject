plaintext is string or hexadecimal
8x8 binary number key. Use function 'keygen' to generate a key.
Mode is 'ENC' (Encode) by default: Input is plain text string.
Use Mode 'DEC' to Decode: Input is hexadecimal string.