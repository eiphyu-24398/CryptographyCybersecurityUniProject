function desAlgorithmencrypt()

str = input('Enter a secret message: ', 's');
KEY =  [1     1     1     0     0     1     0     1
     0     1     0     1     1     0     1     1
     1     1     1     1     0     0     0     1
     0     0     0     1     0     0     1     1
     1     0     0     1     1     0     1     1
     0     0     0     0     1     1     1     0
     1     1     1     1     1     0     0     0
     1     0     0     1     0     1     0     0];
Mode = 'ENC'

DESOUT=DES(str,KEY,Mode)

end