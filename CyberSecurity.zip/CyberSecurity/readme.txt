CST4135 - M00953653

1. Open Matlab
2. Open GUICyberSecurity.m
3. Click on the GUI Dropdown Menu button 
4. Choose the encryption and decryption method as you like.


Reference Lists

RSA
suriyanath (2024). RSA algorithm (https://www.mathworks.com/matlabcentral/fileexchange/46824-rsa-algorithm), MATLAB Central File Exchange. Retrieved January 26, 2024.

DES
Yue Wu (2024). Data Encryption Standard (DES) (https://www.mathworks.com/matlabcentral/fileexchange/37847-data-encryption-standard-des), MATLAB Central File Exchange. Retrieved January 26, 2024.


RC4
Gokula Krishnan (2024). Rc4 Algorithm using Matlab without functions (https://www.mathworks.com/matlabcentral/fileexchange/127344-rc4-algorithm-using-matlab-without-functions), MATLAB Central File Exchange. Retrieved January 26, 2024.

Authenticated Encryption GCM 
David Hill (2024). Galois Counter Mode (GCM) Block Cipher using AES (https://www.mathworks.com/matlabcentral/fileexchange/102850-galois-counter-mode-gcm-block-cipher-using-aes), MATLAB Central File Exchange. Retrieved January 26, 2024.

