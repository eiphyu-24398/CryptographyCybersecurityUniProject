% Creating a MATLAB GUI
fig = uifigure('Name', 'CyberSecurity GUI', 'Position', [100, 100, 400, 300]);

% Creating a menu bar
menuBar = uimenu(fig, 'Text', 'Cyber Security Cryptography');

% Classic Cipher
week1 = uimenu(menuBar, 'Text', 'Classic Cipher');
uimenu(week1, 'Text', 'Caesar Cipher Encode', 'MenuSelectedFcn', @(src, event) caesarCipherencode());
uimenu(week1, 'Text', 'Caesar Cipher Decode', 'MenuSelectedFcn', @(src, event) caesarCipherdecode());
uimenu(week1, 'Text', 'One Time Pad', 'MenuSelectedFcn', @(src, event) onetimePad());
uimenu(week1, 'Text', 'Cryptoanalysis', 'MenuSelectedFcn', @(src, event) cryptoanalysis());
uimenu(week1, 'Text', 'AnalyzeLetterDistribution', 'MenuSelectedFcn', @(src, event) analyzeLetterDistribution());
uimenu(week1, 'Text', 'VectorizationLetterDistribution', 'MenuSelectedFcn', @(src, event) vectorizationLetterDistribution());

% Random Number Generators
week2 = uimenu(menuBar, 'Text', 'Random Number Generators');
uimenu(week2, 'Text', 'Philox 4x32', 'MenuSelectedFcn', @(src, event) philoxGenerator());

% Bitwise 
week3 = uimenu(menuBar, 'Text', 'Bitwise');
uimenu(week3, 'Text', 'XOR Encryption', 'MenuSelectedFcn', @(src, event) bitwisexor());
uimenu(week3, 'Text', 'XOR Encryption Binary', 'MenuSelectedFcn', @(src, event) bitwisexorbinary());

% Block Cipher
week4 = uimenu(menuBar, 'Text', 'DES Block Cipher');
uimenu(week4, 'Text', 'Key Generation', 'MenuSelectedFcn', @(src, event) keyGeneration());
uimenu(week4, 'Text', 'DES Algorithm Encryption', 'MenuSelectedFcn', @(src, event) desAlgorithmencrypt());
uimenu(week4, 'Text', 'DES Algorithm Decryption', 'MenuSelectedFcn', @(src, event) desAlgorithmdecrypt());

% Stream Ciphers
week5 = uimenu(menuBar, 'Text', 'Stream Ciphers');
uimenu(week5, 'Text', 'RC4 Cipher', 'MenuSelectedFcn', @(src, event) rc4Cipher());
uimenu(week5, 'Text', 'XOR stream cipher', 'MenuSelectedFcn', @(src, event) xorCipher());
uimenu(week5, 'Text', 'Custom Stream Cipher', 'MenuSelectedFcn', @(src, event) streamCipher());

% Hashing and CRC
week6 = uimenu(menuBar, 'Text', 'Hashing and CRC');
uimenu(week6, 'Text', 'Hashing Routine', 'MenuSelectedFcn', @(src, event) hashingRoutine());
uimenu(week6, 'Text', 'CRC Routine', 'MenuSelectedFcn', @(src, event) crcRoutine());

% HMAC Hashing
week7 = uimenu(menuBar, 'Text', 'HMAC Hashing');
uimenu(week7, 'Text', 'HMAC Hashing', 'MenuSelectedFcn', @(src, event) hmachash());

% Authenticated Encryption
week8 = uimenu(menuBar, 'Text', 'Authenticated GCM Encryption');
uimenu(week8, 'Text', 'GCM Encryption', 'MenuSelectedFcn', @(src, event) gcmencryption());
uimenu(week8, 'Text', 'GCM Binary Encryption', 'MenuSelectedFcn', @(src, event) gcmbinaryencryption());

% Algorithmic Complexity
week9 = uimenu(menuBar, 'Text', 'Algorithmic Complexity');
uimenu(week9, 'Text', 'Growth Rates Visualization', 'MenuSelectedFcn', @(src, event) growthRatesVisualization());

% RSA Encryption
week10 = uimenu(menuBar, 'Text', 'RSA Encryption');
uimenu(week10, 'Text', 'RSA Algorithm', 'MenuSelectedFcn', @(src, event) rsaAlgorithmEncryption());

% DH/EC 
week11 = uimenu(menuBar, 'Text', 'DH/EC');
uimenu(week11, 'Text', 'DH/EC Key Exchange', 'MenuSelectedFcn', @(src, event) diffiehellman());

% Define callback functions for each menu option
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Classic Cipher
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Ceasar Cipher
function caesarCipherencode()

encode ='Enter the Encode Messge: ';
a = input(encode, 's');

a = lower(a);
l = length(a);
encodedMessage = '';
key = input('Enter a key: ');
for c = 1:l
    ch = a(c);

    asc = unicode2native(ch);
    if ((ch >= 'a') && (ch <= 'z'))
        n = key;
        asc = asc + n;
    if asc > unicode2native('z')
        asc = asc - 26;
    elseif asc < unicode2native('a')
        asc = asc + 26;
    end 
    encodedMessage = [encodedMessage, char(asc)];
    else
end
end

    fprintf('The Encoded Messeage is %s\n', encodedMessage);
 end

 function caesarCipherdecode()

decode = 'Enter the Decode Message: ';
a = input(decode, 's');

a = lower(a);
l = length(a);

decodedMessage = '';
key = input('Enter a key: ');
for c = 1:l
    ch = a(c);

    asc = unicode2native(ch);
    if ((ch >= 'a') && (ch <= 'z'))
        n = key;
        asc = asc - n;
    if asc > unicode2native('z')
        asc = asc - 26;
    elseif asc < unicode2native('a')
        asc = asc + 26;

    end 
    decodedMessage = [decodedMessage, char(asc)];
    else
    end 
end

fprintf('The Decoded Message is %s\n', decodedMessage);
 end

function onetimePad()

msg = input('Enter a secret message: ', 's');
msg = lower(msg);

a = msg;
a = lower(a);
l = length(a);
seq = uint8(l);
secret = '';

for p = 1:l
    seq(p) = randi(25);
end

for c = 1:l
    ch = a(c);
    asc = unicode2native(ch);

    if((ch>='a') && (ch<='z'))
        n = seq(c);
        asc = asc + n;
     
        if asc>unicode2native('z')
            asc = asc - 26;
        elseif asc<unicode2native('a')
            asc = asc + 26;
        end
        secret = [secret, char(asc)];
    else
        n = seq(c);
        secret = [secret, char(asc)];
    end
end
fprintf('The secret message: %s\n', secret);

decoded = '';

for c = 1:l
    ch = secret(c);
    asc = unicode2native(ch);
    
    if((ch>='a') && (ch<='z'))
        n = seq(c);
        asc = asc - n;
        
        if asc>unicode2native('z')
            asc = asc - 26;
        elseif asc<unicode2native('a')
            asc = asc + 26;
        end
        decoded = [decoded, char(asc)];
    else
        n = seq(c);
        decoded = [decoded, char(asc)];
    end
end
fprintf('The decoded message: %s\n', decoded);
end


function cryptoanalysis()
    % Implement cryptoanalysis functionality
    datasetPath = '/MATLAB Drive/CyberSecurity/english_monograms.csv';

% Loading the dataset
data = readtable(datasetPath, 'Delimiter', '\t', 'ReadVariableNames', false);

disp(data);

% combined column into separate columns
splitData = cellfun(@(x) strsplit(x, ','), data.Var1, 'UniformOutput', false);
splitData = vertcat(splitData{:});

% Extracting letters and frequencies
letters = splitData(:, 1);
frequencies = str2double(splitData(:, 2));

% bar graph
bar(letters, frequencies);
xlabel('Letters');
ylabel('Frequency (%)');
title('English Letter Distribution');
grid on;
end

function analyzeLetterDistribution()
    % analyzeLetterDistribution function
    % Specifying the path to the dataset
    datasetPath = '/MATLAB Drive/CyberSecurity/english_monograms.csv';

    % Loading the dataset
    data = readtable(datasetPath, 'Delimiter', '\t', 'ReadVariableNames', false);

    splitData = cellfun(@(x) strsplit(x, ','), data.Var1, 'UniformOutput', false);
    splitData = vertcat(splitData{:});

    letters = splitData(:, 1);
    frequencies = str2double(splitData(:, 2));

    % Accepting user input
    inputText = upper(input('Enter an English language sentence or paragraph: ', 's'));

    % Counting occurrences of each letter in the input text
    letterCounts = zeros(size(letters));
    for i = 1:length(letters)
        letterCounts(i) = sum(inputText == letters{i});
    end

    % Normalizing the counts to percentages
    letterPercentages = (letterCounts / length(inputText)) * 100;

    % bar graph
    figure;
    bar(letters, letterPercentages);

    xlabel('Letters');
    ylabel('Frequency (%)');
    title('Letter Distribution in Input Text');
    grid on;
end

function vectorizationLetterDistribution()
    % vectorizationLetterDistribution function
    % Specifying the path to the dataset
    datasetPath = '/MATLAB Drive/CyberSecurity/english_monograms.csv';

    % Loading the dataset
    data = readtable(datasetPath, 'Delimiter', '\t', 'ReadVariableNames', false);

    splitData = cellfun(@(x) strsplit(x, ','), data.Var1, 'UniformOutput', false);
    splitData = vertcat(splitData{:});

    letters = splitData(:, 1);
    frequencies = str2double(splitData(:, 2));

    inputText = upper(input('Enter an English language sentence or paragraph: ', 's'));

    letterCounts = zeros(size(letters));
    for i = 1:length(letters)
        letterCounts(i) = sum(strcmp(inputText, letters{i}));
    end

    letterPercentages = (letterCounts / length(inputText)) * 100;

    figure;
    bar(letters, letterPercentages);

    xlabel('Letters');
    ylabel('Frequency (%)');
    title('Letter Distribution in Input Text');
    grid on;
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Random Number Generators
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function philoxGenerator()
    % Philox 4x32 generator function
    % random number generators
rng_default = RandStream('mt19937ar');
rng_dsfmt19937 = RandStream('dsfmt19937', 'Seed', 'shuffle');
rng_philox = RandStream('philox4x32_10', 'Seed', 'shuffle');

% One-Time Pad with a randomly chosen generator
rng_selected = randi([1, 3]); % Choose a random generator (1, 2, or 3)
rng_selected_stream = {rng_default, rng_dsfmt19937, rng_philox};
selected_rng = rng_selected_stream{rng_selected};

plain_text_example = input('Enter a message: ', 's');
encrypted_text_example = one_time_pad_char(double(plain_text_example), selected_rng);
disp(['Plain Text: ', plain_text_example]);
disp(['Encrypted Text: ', encrypted_text_example]);

% random numbers using different generators
random_values_default = rand(rng_default, 10000, 1);
random_values_dsfmt19937 = rand(rng_dsfmt19937, 10000, 1);
random_values_philox = rand(rng_philox, 10000, 1);

% output of different generators
figure;
subplot(3,1,1);
histogram(random_values_default, 'DisplayName', 'Mersenne Twister');
title('Mersenne Twister');

subplot(3,1,2);
histogram(random_values_dsfmt19937, 'DisplayName', 'SIMD-oriented Fast Mersenne Twister');
title('SIMD-oriented Fast Mersenne Twister');

subplot(3,1,3);
histogram(random_values_philox, 'DisplayName', 'Philox 4x32 with 10 rounds');
title('Philox 4x32 with 10 rounds');
xlabel('Random Values');

% One-Time Pad implementation using a randomly chosen generator
function encrypted_text = one_time_pad_char(plain_text, rng)
    plain_text = upper(plain_text);
    key = randi(rng, [1, 26], size(plain_text)) - 1; 
    encrypted_text = char(mod(plain_text - 'A' + key, 26) + 'A');
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Bitwise
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function bitwisexor()
% XOR encryption with a key
plaintext = input('Enter a message: ', 's');
key = 'EDR141'; 

% XOR encryption
encrypted_binary = xor_encrypt(plaintext, key);

% Encrypted binary with the same key again
decrypted_binary = xor_encrypt(encrypted_binary, key);

decrypted_str = char(bin2dec(reshape(char(decrypted_binary + '0'), 8, []).'));

% Decrypted string
disp('Decrypted String:');
disp(decrypted_str);

% Decrypted string matches the original plaintext
disp('Is Decryption Correct?');
disp(strcmp(plaintext, decrypted_str));

% XOR encryption at bitwise level
function encrypted_binary = xor_encrypt(plaintext, key)
    binary = reshape(dec2bin(plaintext, 8).' - '0', 1, []);

    key = repmat(key, 1, ceil(length(binary) / length(key)));

    % XOR operation
    encrypted_binary = xor(binary, key(1:length(binary)));

    disp('Encrypted Binary:');
    disp(encrypted_binary);

    encrypted_str = char(bin2dec(reshape(char(encrypted_binary + '0'), 8, []).'));

    disp('Encrypted String:');
    disp(encrypted_str);
end
end


%Binary
function bitwisexorbinary(msg)

msg = input('Enter a secret message: ', 's');
msg = lower(msg);
key = input('Enter a key: ', 's');

% length of text and key
textLength = length(msg);
keyLength = length(key);

% Initialize encrypted text and decrypted text arrays
encryptedText = zeros(1, textLength, 'uint32');
decryptedText = char(zeros(1, textLength));

% Encrypting the text using XOR operation
for i = 1:textLength
    encryptedText(i) = bitxor(uint32(msg(i)), uint32(key(mod(i-1, keyLength) + 1)));
end

% Displaying the encrypted text (numeric ASCII codes)
fprintf('Encrypted Text (in ASCII codes): ');
disp(encryptedText);

% Decrypting the text using XOR operation
for i = 1:textLength
    decryptedText(i) = char(bitxor(encryptedText(i), uint32(key(mod(i-1, keyLength) + 1))));
end 

% Displaying the decrypted text
fprintf('Decrypted Text: %s\n', decryptedText);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Block Cipher
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function keyGeneration(~, ~)
    % key Generation function
    % Prompt for input values
    n = input('Enter the number of keys (default is 1): ');
    m = input('Enter the number of initialization vectors (default is 1): ');

    % Validate and set default values
    if isempty(n) || ~isnumeric(n) || n <= 0
        n = 1;
    end

    if isempty(m) || ~isnumeric(m) || m <= 0
        m = 1;
    end

    % Call the modified keygen function
    keys = keygen(n, m);

    % Display the generated keys
    disp('Generated Keys:');
    disp(keys);
end

function keys = keygen(n, m)
    keys = cell(n, m);

    for i = 1:n
        for j = 1:m
            key = round(rand(8, 7));
            key(:, 8) = mod(sum(key, 2) + 1, 2);
            keys{i, j} = key;

            if n > 1
                keys{i, j + 1} = round(rand(8, 8)); % Initialization Vectors
            end
        end
    end
end


%desalgorithm
function desAlgorithmencrypt()

str = input('Enter a secret message: ', 's');
KEY =  [1     1     1     0     0     1     0     1
     0     1     0     1     1     0     1     1
     1     1     1     1     0     0     0     1
     0     0     0     1     0     0     1     1
     1     0     0     1     1     0     1     1
     0     0     0     0     1     1     1     0
     1     1     1     1     1     0     0     0
     1     0     0     1     0     1     0     0];
Mode = 'ENC'

DESOUT=DES(str,KEY,Mode)

end


function desAlgorithmdecrypt()

str = input('Enter a secret message: ', 's');
KEY =  [1     1     1     0     0     1     0     1
     0     1     0     1     1     0     1     1
     1     1     1     1     0     0     0     1
     0     0     0     1     0     0     1     1
     1     0     0     1     1     0     1     1
     0     0     0     0     1     1     1     0
     1     1     1     1     1     0     0     0
     1     0     0     1     0     1     0     0];
Mode = 'DEC'

DESOUT=DES(str,KEY,Mode)

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Stream Ciphers
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function rc4Cipher()
    % RC4 Cipher function
    % RC4 cipher
plaintext = input('Enter a secret message: ', 's');
key = 'secretkey';

encrypted_text_rc4 = rc4_cipher(plaintext, key);

disp('Original Text:');
disp(plaintext);
disp('Encrypted Text (RC4):');
disp(encrypted_text_rc4);

function encrypted_text = rc4_cipher(plaintext, key)
    S = rc4_key_schedule(key);
    
    % Text to ASCII values
    text_ascii = double(plaintext);
    
    % Encryption using RC4
    encrypted_ascii = rc4_process(text_ascii, S);
    
    % Convertion back to characters
    encrypted_text = char(encrypted_ascii);
end

function S = rc4_key_schedule(key)
    key_length = length(key);
    
    % Initialization S array
    S = 0:255;
    
    % Key-scheduling algorithm
    j = 0;
    for i = 1:256
        j = mod(j + S(i) + key(mod(i - 1, key_length) + 1), 256) + 1;
        % Swap S(i) and S(j)
        temp = S(i);
        S(i) = S(j);
        S(j) = temp;
    end
end

function output = rc4_process(input, S)
    % Initialization
    i = 1;
    j = 0;
    
    % Pseudo-random generation algorithm
    output = input;
    for k = 1:length(input)
        i = mod(i + 1, 256);
        j = mod(j + S(i + 1), 256);
        
        % Swap S(i) and S(j)
        temp = S(i + 1);
        S(i + 1) = S(j + 1);
        S(j + 1) = temp;
        
        % Pseudo-random byte
        t = mod(S(i + 1) + S(j + 1), 256);
        output(k) = bitxor(input(k), S(t + 1));
    end
end
end

function xorCipher()
    % XOR stream cipher function
    % XOR stream cipher
plaintext = input('Enter a secret message: ', 's');
key = 'secretkey';
encrypted_text = xor_stream_cipher(plaintext, key);
disp('Original Text:');
disp(plaintext);
disp('Encrypted Text:');
disp(encrypted_text);

function encrypted_text = xor_stream_cipher(plaintext, key)
    % Text and key to ASCII values
    text_ascii = double(plaintext);
    key_ascii = double(key);
    
    % Key is as long as the plaintext
    key_repeated = repmat(key_ascii, 1, ceil(length(text_ascii) / length(key_ascii)));

    % XOR operation
    encrypted_ascii = bitxor(text_ascii, key_repeated(1:length(text_ascii)));

    % ASCII values of encrypted characters
    disp('Encrypted ASCII Values:');
    disp(encrypted_ascii);

    % Converting back to characters
    encrypted_text = char(encrypted_ascii);
end
end

function streamCipher()
    % Custom Stream Cipher function
    % Custom stream cipher
plaintext = input('Enter a secret message: ', 's');
key = 'customkey';
encrypted_text_custom = custom_stream_cipher(plaintext, key);
disp('Original Text:');
disp(plaintext);
disp('Encrypted Text (Custom Stream Cipher):');
disp(encrypted_text_custom);

function encrypted_text = custom_stream_cipher(plaintext, key)
    % Converting text and key to ASCII values
    text_ascii = double(plaintext);
    key_ascii = double(key);
    
    % Key is as long as the plaintext
    key_repeated = repmat(key_ascii, 1, ceil(length(text_ascii) / length(key_ascii)));

    % Keystream based on the key
    keystream = generate_keystream(key_repeated(1:length(text_ascii)));
    
    % XOR operation
    encrypted_ascii = bitxor(text_ascii, keystream);

    % Converting back to characters
    encrypted_text = char(encrypted_ascii);
end

function keystream = generate_keystream(key)
    % Key scheduling algorithm 
    key_length = length(key);
    keystream = zeros(1, key_length);
    
    for i = 1:key_length
        keystream(i) = bitshift(key(i), mod(i, 8));
    end
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Hashing and CRC
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function hashingRoutine()
    % Hashing Routine function
    % Message for the hashing routine
message = input('Enter Message: ', 's');
hashValue = simpleHash(message);
disp(['Hash Value for Message: ', num2str(hashValue)]);
function hashValue = simpleHash(message)
    % Simple hashing routine
    hashValue = sum(double(message));
end
end

function crcRoutine()
    % CRC Routine function
    % CRC routine with a message
message = input('Enter Message: ', 's');
crcValue = simpleCRC(uint8(message));
disp(['CRC Value for Message: ', num2str(crcValue)]);

% Example for the CRC routine with a file
filePath = '/MATLAB Drive/CyberSecurity/file2.txt';
fileData = fileread(filePath);
crcValue = simpleCRC(uint8(fileData));
disp(['CRC Value for File: ', num2str(crcValue)]);
function crcValue = simpleCRC(data)
    % Simple CRC routine for messages or files

    % CRC polynomial coefficients (CRC-32)
    polynomial = uint32(hex2dec('EDB88320'));

    % Initialize CRC value
    crcValue = uint32(4294967295);  

    % Process each byte in the data
    for byte = data
        crcValue = bitxor(bitshift(crcValue, -8), polynomial);
        crcValue = bitxor(crcValue, uint32(byte));
        
        for bitIndex = 1:8  % Fixed the variable name
            if bitget(crcValue, 1)
                crcValue = bitxor(bitshift(crcValue, -1), polynomial);
            else
                crcValue = bitshift(crcValue, -1);
            end
        end
    end

    crcValue = bitxor(crcValue, uint32(4294967295));
end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HMAC Hashing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function hmachash()

key = 'my secret important key';
message = input('Enter Message: ', 's');

mac = HMAC(key,message,'SHA-256');
disp(['Computed HMAC:',mac])
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  GCM Block Cipher
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function gcmencryption()

key='44a74c1a57da2bf6d6838956cdca13f1b67cc6ad87d459bff544784083868171';
iv='4392367e62ef9aa706e3e801';
plainTextInput = input('Enter a secret message: ', 's');
aad= 'additional unencrypted instructions';
[C,T]=GCM_AE(key,iv,plainTextInput,aad)
end

function gcmbinaryencryption()

key='44a74c1a57da2bf6d6838956cdca13f1b67cc6ad87d459bff544784083868171';
iv='4392367e62ef9aa706e3e801';

aad= 'additional unencrypted instructions';

C = input('Enter C: ', 's');
T = input('Enter T: ', 's');
    
[P,A]=GCM_AD(key,iv,C,aad,T)
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Algorithmic Complexity
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function growthRatesVisualization()
    % Growth Rates Visualization function
    % Visualization of Growth Rates
% Generating input values (n)
n = 1:20;

% Plotting constant, linear, logarithmic, quadratic, and exponential growth
figure;
plot(n, ones(size(n)), '-o', 'DisplayName', 'O(1) - Constant');
hold on;
plot(n, n, '-o', 'DisplayName', 'O(n) - Linear');
plot(n, log2(n), '-o', 'DisplayName', 'O(log n) - Logarithmic');
plot(n, n.^2, '-o', 'DisplayName', 'O(n^2) - Quadratic');
plot(n, 2.^n, '-o', 'DisplayName', 'O(2^n) - Exponential');

% Setting axis labels and title
xlabel('Input Size (n)');
ylabel('Operations');
title('Complexity Growth Rates');
legend('Location', 'northwest');

% Timing Mechanisms

% Using tic and toc
tic;
constantTime();
elapsedTime = toc;
disp(['Elapsed Time: ', num2str(elapsedTime), ' seconds']);

% Using timeit function
elapsedTime = timeit(@() linearTime(100));
disp(['Elapsed Time: ', num2str(elapsedTime), ' seconds']);

% Using profile
profile on;
quadraticTime(50);
profile off;

% Checking if profview is supported
if ~isdeployed
    try
        profview;
    catch
        disp('profview is not supported on this platform.');
    end
else
    disp('profview is not supported on this platform.');
end

% Importance of Complexity in Cryptography
disp('The measure of complexity is important in cryptography because:');
disp('- Cryptographic algorithms need to be efficient to handle large data sets.');
disp('- Time complexity affects the practicality of the algorithm in real-world applications.');
disp('- A balance between security and performance is crucial for cryptographic algorithms.');


% Stats Option in the Menu
disp('You can implement a stats option in the menu to provide information on timings, memory usage, etc.');


% Time Complexity Demonstrations

% Constant time complexity - O(1)
function constantTime()
    disp('Constant Time Complexity - O(1)');
end

% Linear time complexity - O(n)
function linearTime(n)
    disp(['Linear Time Complexity - O(n), n = ', num2str(n)]);
    for i = 1:n
        
    end
end

% Logarithmic time complexity - O(log n)
function logarithmicTime(n)
    disp(['Logarithmic Time Complexity - O(log n), n = ', num2str(n)]);
    for i = 1:log2(n)
        
    end
end

% Quadratic time complexity - O(n^2)
function quadraticTime(n)
    disp(['Quadratic Time Complexity - O(n^2), n = ', num2str(n)]);
    for i = 1:n
        for j = 1:n
            
        end
    end
end

% Exponential time complexity - O(2^n)
function exponentialTime(n)
    disp(['Exponential Time Complexity - O(2^n), n = ', num2str(n)]);
    for i = 1:2^n
       
    end
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RSA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function rsaAlgorithmEncryption()

p = input('\nEnter the value of p: ');
q = input('\nEnter the value of q: ');
[Pk,Phi,d,e] = intialize(p,q);
M = input('\nEnter the message: ','s');
x=length(M);
c=0;
for j= 1:x
    for i=0:122
        if strcmp(M(j),char(i))
            c(j)=i;
        end
    end
end
disp('ASCII Code of the entered Message:');
disp(c); 
% % %Encryption
for j= 1:x
   cipher(j)= crypt(c(j),Pk,e); 
end
disp('Cipher Text of the entered Message:');
disp(cipher);
% % %Decryption
for j= 1:x
   message(j)= crypt(cipher(j),Pk,d); 
end
disp('Decrypted ASCII of Message:');
disp(message);
disp(['Decrypted Message is: ' message]);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DH/EC Key Exchange
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function diffiehellman()
disp('Diffie Hellman Key Exchange');
disp('-----------------------------------------');
%Clear variables in workspace and close figure
%Input value of g and p, and ensure that g and p is prime
prime = 0;
while prime == 0
    g = input('Enter a value for g: ');
    p = input('Enter a Value for p: ');
    pg = isprime(g);
    pp = isprime(p);
    if pg == 0
        disp('g is not prime');
    end
    if pp == 0
        disp('p is not prime');
    end
    prime = pg & pp;
end
disp('---Value For X---');
xa = randi([1 p-1]);%Calculate value of Xa
xb = randi([1 p-1]);%Calculate value of Xb
disp(['Xa is: ' num2str(xa)]);%Convert xa to string and display it
disp(['Xb is: ' num2str(xb)]);%Convert xb to string and display it
disp('---Value For Y---');
%Calculate value of Ya and Yb
ya = power(g,xa);
ya = mod(ya,p);
yb = power(g,xb);
yb = mod(yb,p);
disp(['Ya is : ' num2str(ya)]);%Convert ya to string and display it
disp(['Yb is : ' num2str(yb)]);%Convert yb to string and display it
disp('---The Shared Key---');
%Calculate shared key
ha = power(yb,xa);
ha = mod(ha,p);
hb = power(ya,xb);
hb = mod(hb,p);
disp(['Shared Key A: ' num2str(ha)]);%Convert ha to string and display it
disp(['Shared Key B: ' num2str(hb)]);%Convert bb to string and display it
end