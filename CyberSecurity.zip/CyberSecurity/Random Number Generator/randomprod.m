% random number generators
rng_default = RandStream('mt19937ar');
rng_dsfmt19937 = RandStream('dsfmt19937', 'Seed', 'shuffle');
rng_philox = RandStream('philox4x32_10', 'Seed', 'shuffle');

% One-Time Pad with a randomly chosen generator
rng_selected = randi([1, 3]); % Choose a random generator (1, 2, or 3)
rng_selected_stream = {rng_default, rng_dsfmt19937, rng_philox};
selected_rng = rng_selected_stream{rng_selected};

plain_text_example = 'HELLO';
encrypted_text_example = one_time_pad_char(double(plain_text_example), selected_rng);
disp(['Plain Text: ', plain_text_example]);
disp(['Encrypted Text: ', encrypted_text_example]);

% random numbers using different generators
random_values_default = rand(rng_default, 10000, 1);
random_values_dsfmt19937 = rand(rng_dsfmt19937, 10000, 1);
random_values_philox = rand(rng_philox, 10000, 1);

% output of different generators
figure;
subplot(3,1,1);
histogram(random_values_default, 'DisplayName', 'Mersenne Twister');
title('Mersenne Twister');

subplot(3,1,2);
histogram(random_values_dsfmt19937, 'DisplayName', 'SIMD-oriented Fast Mersenne Twister');
title('SIMD-oriented Fast Mersenne Twister');

subplot(3,1,3);
histogram(random_values_philox, 'DisplayName', 'Philox 4x32 with 10 rounds');
title('Philox 4x32 with 10 rounds');
xlabel('Random Values');

% One-Time Pad implementation using a randomly chosen generator
function encrypted_text = one_time_pad_char(plain_text, rng)
    plain_text = upper(plain_text);
    key = randi(rng, [1, 26], size(plain_text)) - 1; 
    encrypted_text = char(mod(plain_text - 'A' + key, 26) + 'A');
end
