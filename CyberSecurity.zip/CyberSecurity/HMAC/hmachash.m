function hmachash()

key = 'mysecretimportantkey';
message = input('Enter Message: ', 's');

mac = HMAC(key,message,'SHA-256');
disp(['Computed HMAC:',mac])
end