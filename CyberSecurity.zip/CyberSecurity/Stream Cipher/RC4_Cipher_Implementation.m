function rc4()
% RC4 cipher
plaintext = input('Enter a secret message: ', 's');
key = 'secretkey';

encrypted_text_rc4 = rc4_cipher(plaintext, key);

disp('Original Text:');
disp(msg);
disp('Encrypted Text (RC4):');
disp(encrypted_text_rc4);



function encrypted_text = rc4_cipher(plaintext, key)
    S = rc4_key_schedule(key);
    
    % Text to ASCII values
    text_ascii = double(plaintext);
    
    % Encryption using RC4
    encrypted_ascii = rc4_process(text_ascii, S);
    
    % Convertion back to characters
    encrypted_text = char(encrypted_ascii);
end

function S = rc4_key_schedule(key)
    key_length = length(key);
    
    % Initialization S array
    S = 0:255;
    
    % Key-scheduling algorithm
    j = 0;
    for i = 1:256
        j = mod(j + S(i) + key(mod(i - 1, key_length) + 1), 256) + 1;
        % Swap S(i) and S(j)
        temp = S(i);
        S(i) = S(j);
        S(j) = temp;
    end
end

function output = rc4_process(input, S)
    % Initialization
    i = 1;
    j = 0;
    
    % Pseudo-random generation algorithm
    output = input;
    for k = 1:length(input)
        i = mod(i + 1, 256);
        j = mod(j + S(i + 1), 256);
        
        % Swap S(i) and S(j)
        temp = S(i + 1);
        S(i + 1) = S(j + 1);
        S(j + 1) = temp;
        
        % Pseudo-random byte
        t = mod(S(i + 1) + S(j + 1), 256);
        output(k) = bitxor(input(k), S(t + 1));
    end
end
end
