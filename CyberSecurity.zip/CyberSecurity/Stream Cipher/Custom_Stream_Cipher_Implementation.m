function customstreamcipher()
plaintext = input('Enter a secret message: ', 's');
key = 'customkey';

encrypted_text_custom = custom_stream_cipher(plaintext, key);

disp('Original Text:');
disp(plaintext);
disp('Encrypted Text (Custom Stream Cipher):');
disp(encrypted_text_custom);


function encrypted_text = custom_stream_cipher(plaintext, key)
    % Converting text and key to ASCII values
    text_ascii = double(plaintext);
    key_ascii = double(key);
    
    % Key is as long as the plaintext
    key_repeated = repmat(key_ascii, 1, ceil(length(text_ascii) / length(key_ascii)));

    % Keystream based on the key
    keystream = generate_keystream(key_repeated(1:length(text_ascii)));
    
    % XOR operation
    encrypted_ascii = bitxor(text_ascii, keystream);

    % Converting back to characters
    encrypted_text = char(encrypted_ascii);
end

function keystream = generate_keystream(key)
    % Key scheduling algorithm 
    key_length = length(key);
    keystream = zeros(1, key_length);
    
    for i = 1:key_length
        keystream(i) = bitshift(key(i), mod(i, 8));
    end
end
end
