function xorstreamcipher()
% XOR stream cipher
plaintext = input('Enter a secret message: ', 's');
key = 'secretkey';

encrypted_text = xor_stream_cipher(plaintext, key);

disp('Original Text:');
disp(plaintext);
disp('Encrypted Text:');
disp(encrypted_text);


function encrypted_text = xor_stream_cipher(plaintext, key)
    % Text and key to ASCII values
    text_ascii = double(plaintext);
    key_ascii = double(key);
    
    % Key is as long as the plaintext
    key_repeated = repmat(key_ascii, 1, ceil(length(text_ascii) / length(key_ascii)));

    % XOR operation
    encrypted_ascii = bitxor(text_ascii, key_repeated(1:length(text_ascii)));

    % ASCII values of encrypted characters
    disp('Encrypted ASCII Values:');
    disp(encrypted_ascii);

    % Converting back to characters
    encrypted_text = char(encrypted_ascii);
end
end
