function gcmencryption()

key='44a74c1a57da2bf6d6838956cdca13f1b67cc6ad87d459bff544784083868171';
iv='4392367e62ef9aa706e3e801';
plainTextInput = input('Enter a secret message: ', 's');
aad= 'additional unencrypted instructions';
[C,T]=GCM_AE(key,iv,plainTextInput,aad)
end