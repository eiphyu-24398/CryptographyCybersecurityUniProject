function gcmbinaryencryption()

key='44a74c1a57da2bf6d6838956cdca13f1b67cc6ad87d459bff544784083868171';
iv='4392367e62ef9aa706e3e801';

aad= 'additional unencrypted instructions';

C = input('Enter C: ', 's');
T = input('Enter T: ', 's');
    
[P,A]=GCM_AD(key,iv,C,aad,T)
end