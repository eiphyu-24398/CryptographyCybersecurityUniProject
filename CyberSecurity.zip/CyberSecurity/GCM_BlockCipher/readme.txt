{\rtf1\ansi\ansicpg1252\cocoartf2709
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\froman\fcharset0 TimesNewRomanPSMT;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;\red255\green255\blue255;\red142\green0\blue238;
}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c0;\cssrgb\c100000\c100000\c99985\c0;\cssrgb\c63458\c13312\c94849;
}
\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs28 \cf2 \cb3 \expnd0\expndtw0\kerning0
key=\cb3 '44a74c1a57da2bf6d6838956cdca13f1b67cc6ad87d459bff544784083868171'\cb3 ;\
iv=\cb3 '4392367e62ef9aa706e3e801'\cb3 ;\
plainTextInput=\cb3 'I like to swim!'\cb3 ;\
aad= \cb3 'additional unencrypted instructions'\cb3 ;\
[C,T]=GCM_AE(key,iv,plainTextInput,aad)\
C =\
\
    \cb3 '6deb6e66165c0f8d85369aa4da0c1d'\cb3 \
\
\
T =\
\
    \cb3 '1ec4fb95081845d94bca1c4d'\cb3 \
    \
[P,A]=GCM_AD(key,iv,C,aad,T)\
P =\
\
    \cb3 'I like to swim!'\cb3 \
\
\
A =\
\
  logical\
\
   1}