% Message for the hashing routine
message = 'Lets Hashing Together';
hashValue = simpleHash(message);
disp(['Hash Value for Message: ', num2str(hashValue)]);
function hashValue = simpleHash(message)
    % Simple hashing routine
    hashValue = sum(double(message));
end
