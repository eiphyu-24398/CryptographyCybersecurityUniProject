% cryptoModule.m
function hashValue = simpleHash(message)
    % Simple hashing routine
    hashValue = sum(double(message));
end

function crcValue = simpleCRC(data)

    % CRC polynomial coefficients (CRC-32)
    polynomial = uint32(hex2dec('EDB88320'));

    % Initializing CRC value
    crcValue = uint32(4294967295);  % Initial CRC value (complement of zero)

    % Processing each byte in the data
    for byte = data
        crcValue = bitxor(bitshift(crcValue, -8), polynomial);
        crcValue = bitxor(crcValue, uint32(byte));
        
        for bitIndex = 1:8
            if bitget(crcValue, 1)
                crcValue = bitxor(bitshift(crcValue, -1), polynomial);
            else
                crcValue = bitshift(crcValue, -1);
            end
        end
    end

    crcValue = bitxor(crcValue, uint32(4294967295));
end
