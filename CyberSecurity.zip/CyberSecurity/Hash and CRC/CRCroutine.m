% CRC routine with a message
message = 'Check this message with CRC';
crcValue = simpleCRC(uint8(message));
disp(['CRC Value for Message: ', num2str(crcValue)]);

% Example for the CRC routine with a file
filePath = '/MATLAB Drive/CyberSecurity/file2.txt';
fileData = fileread(filePath);
crcValue = simpleCRC(uint8(fileData));
disp(['CRC Value for File: ', num2str(crcValue)]);
function crcValue = simpleCRC(data)
    % Simple CRC routine for messages or files

    % CRC polynomial coefficients (CRC-32)
    polynomial = uint32(hex2dec('EDB88320'));

    % Initialize CRC value
    crcValue = uint32(4294967295);  

    % Process each byte in the data
    for byte = data
        crcValue = bitxor(bitshift(crcValue, -8), polynomial);
        crcValue = bitxor(crcValue, uint32(byte));
        
        for bitIndex = 1:8  % Fixed the variable name
            if bitget(crcValue, 1)
                crcValue = bitxor(bitshift(crcValue, -1), polynomial);
            else
                crcValue = bitshift(crcValue, -1);
            end
        end
    end

    crcValue = bitxor(crcValue, uint32(4294967295));
end
