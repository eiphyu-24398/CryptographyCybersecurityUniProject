function onetimePad()

msg = input('Enter a secret message: ', 's');
msg = lower(msg);

a = msg;
a = lower(a);
l = length(a);
seq = uint8(l);
secret = '';

for p = 1:l
    seq(p) = randi(25);
end

for c = 1:l
    ch = a(c);
    asc = unicode2native(ch);

    if((ch>='a') && (ch<='z'))
        n = seq(c);
        asc = asc + n;
     
        if asc>unicode2native('z')
            asc = asc - 26;
        elseif asc<unicode2native('a')
            asc = asc + 26;
        end
        secret = [secret, char(asc)];
    else
        n = seq(c);
        secret = [secret, char(asc)];
    end
end
fprintf('The secret message: %s\n', secret);

decoded = '';

for c = 1:l
    ch = secret(c);
    asc = unicode2native(ch);
    
    if((ch>='a') && (ch<='z'))
        n = seq(c);
        asc = asc - n;
        
        if asc>unicode2native('z')
            asc = asc - 26;
        elseif asc<unicode2native('a')
            asc = asc + 26;
        end
        decoded = [decoded, char(asc)];
    else
        n = seq(c);
        decoded = [decoded, char(asc)];
    end
end
fprintf('The decoded message: %s\n', decoded);

