function analyzeLetterDistribution(~)
    % Specifying the path to the dataset
    datasetPath = '/MATLAB Drive/CyberSecurity/english_monograms.csv';

    % Loading the dataset
    data = readtable(datasetPath, 'Delimiter', '\t', 'ReadVariableNames', false);

    splitData = cellfun(@(x) strsplit(x, ','), data.Var1, 'UniformOutput', false);
    splitData = vertcat(splitData{:});

    letters = splitData(:, 1);
    frequencies = str2double(splitData(:, 2));

    % Accepting user input
    inputText = upper(input('Enter an English language sentence or paragraph: ', 's'));

    % Counting occurrences of each letter in the input text
    letterCounts = zeros(size(letters));
    for i = 1:length(letters)
        letterCounts(i) = sum(inputText == letters{i});
    end

    % Normalizing the counts to percentages
    letterPercentages = (letterCounts / length(inputText)) * 100;

    % bar graph
    figure;
    bar(letters, letterPercentages);

    xlabel('Letters');
    ylabel('Frequency (%)');
    title('Letter Distribution in Input Text');
    grid on;
end

