 function caesarCipherdecode()

decode = 'Enter the Decode Message: ';
a = input(decode, 's');

a = lower(a);
l = length(a);

decodedMessage = '';
key = input('Enter a key: ');
for c = 1:l
    ch = a(c);

    asc = unicode2native(ch);
    if ((ch >= 'a') && (ch <= 'z'))
        n = key;
        asc = asc - n;
    if asc > unicode2native('z')
        asc = asc - 26;
    elseif asc < unicode2native('a')
        asc = asc + 26;

    end 
    decodedMessage = [decodedMessage, char(asc)];
    else
    end 
end

fprintf('The Decoded Message is %s\n', decodedMessage);
 end
