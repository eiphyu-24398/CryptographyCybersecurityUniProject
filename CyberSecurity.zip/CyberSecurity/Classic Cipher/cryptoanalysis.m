function cryptoanalysis(~)

datasetPath = '/MATLAB Drive/CyberSecurity/english_monograms.csv';

% Loading the dataset
data = readtable(datasetPath, 'Delimiter', '\t', 'ReadVariableNames', false);

disp(data);

% combined column into separate columns
splitData = cellfun(@(x) strsplit(x, ','), data.Var1, 'UniformOutput', false);
splitData = vertcat(splitData{:});

% Extracting letters and frequencies
letters = splitData(:, 1);
frequencies = str2double(splitData(:, 2));

% bar graph
bar(letters, frequencies);
xlabel('Letters');
ylabel('Frequency (%)');
title('English Letter Distribution');
grid on;
