function ceasarCipherencode()

msg = input('Enter a secret message: ', 's');
msg = lower(msg);

disp('Welcome to Caesar Cipher')
a = msg;
a = lower(a);
secret = '';
shift = 4;

for c = 1:length(a)
    ch = a(c);
    asc = unicode2native(ch);

if ((ch>='a') && (ch<='z'))
   n = shift;
   asc = asc + n;
    if asc>unicode2native('z')
        asc = asc - 26;
    elseif asc<unicode2native('a')
        asc = asc + 26;
    end

    secret = [secret, char(asc)];

else
    secret = [secret, char(asc)];
end

end
disp('Your caesar message is: ');
disp(secret);
end
